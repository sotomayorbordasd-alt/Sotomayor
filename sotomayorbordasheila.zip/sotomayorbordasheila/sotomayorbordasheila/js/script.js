// slider
var slides = document.querySelectorAll(".slide");
var puntos = document.querySelectorAll(".punto");
var actual = 0;

function mostrar(n) {
    slides[actual].classList.remove("activa");
    puntos[actual].classList.remove("activo");
    actual = n;
    slides[actual].classList.add("activa");
    puntos[actual].classList.add("activo");
}

puntos.forEach(function (punto) {
    punto.addEventListener("click", function () {
        mostrar(Number(punto.dataset.n));
    });
});

setInterval(function () {
    mostrar((actual + 1) % slides.length);
}, 4000);

// formulario
var formulario = document.getElementById("formulario");

formulario.addEventListener("submit", function (e) {
    e.preventDefault();

    var registro = {
        nombre: document.getElementById("nombre").value,
        correo: document.getElementById("correo").value,
        telefono: document.getElementById("telefono").value
    };

    var registros = JSON.parse(localStorage.getItem("registros")) || [];
    registros.push(registro);
    localStorage.setItem("registros", JSON.stringify(registros));

    alert("Datos guardados correctamente");
    formulario.reset();
});
