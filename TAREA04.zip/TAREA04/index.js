const nombre = document.getElementById("nombre");
const correo = document.getElementById("correo");
const clave = document.getElementById("clave");
const mensaje = document.getElementById("mensaje");
const enviar = document.getElementById("enviar");

enviar.addEventListener("click", function () {

    const datos = {
        nombre: nombre.value,
        correo: correo.value,
        celular: clave.value
    }

    let lista = JSON.parse(localStorage.getItem("contactos")) || [];
    lista.push(datos);
    localStorage.setItem("contactos", JSON.stringify(lista));

    fetch('http://167.71.101.78/senati/fpw/reserva.php', {
        method: "POST",
        body: JSON.stringify(datos),
        headers: {"Content-type": "application/json; charset=UTF-8"}
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
        if(data.status === 200) {
            mensaje.innerHTML = "SE REGISTRÓ SATISFACTORIAMENTE";
        } else {
            mensaje.innerHTML = "Error: " + data.message;
        }
    })
    .catch(error => console.log(error));
});
