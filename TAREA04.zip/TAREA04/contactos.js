const tabla = document.getElementById("tabla");
const lista = JSON.parse(localStorage.getItem("contactos")) || [];

for (let i = 0; i < lista.length; i++) {
    tabla.innerHTML += "<tr><td>" + lista[i].nombre + "</td><td>" + lista[i].correo + "</td><td>" + lista[i].celular + "</td></tr>";
}
